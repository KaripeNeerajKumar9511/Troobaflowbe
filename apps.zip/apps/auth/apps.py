from django.apps import AppConfig


class AuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.auth'
    label = 'apps_auth'  # avoid conflict with django.contrib.auth (label 'auth')
